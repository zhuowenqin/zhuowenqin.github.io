# KCL PPE for Public Policy Graduate Conference 2025 — Website
Static site ready for GitHub Pages.

## Deploy (branch)
1. Create a public repo.
2. Upload all files to the repo root.
3. Settings → Pages → Build from branch: `main` / `(root)`.
4. Visit `https://<username>.github.io/<repo>/`.

## Edit
- Replace the contact placeholder in `index.html`.
- Update room/badges if needed.
- Replace `poster.png` to update the poster.
